package com.administrator.abstractviewsample;

import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.administrator.abstractviewsample.AbstractView.AbstractActivity;

public class MainActivity extends AbstractActivity {

    @Override
    protected int getLayoutResId() {
        return R.layout.activity_main;
    }

    @Override
    protected void initView() {

        $Title(R.id.AbstractViewSample, getString(R.string.app_name));
        $Finish(R.id.AbstractViewSample4);//If you want do something before finish, just override beforeFinish();

        LinearLayout layout = $find(R.id.layout_AbstractViewSample);
        layout.setBackgroundResource(R.color.white);

        $click(R.id.AbstractViewSample1);

        final TextView tv = $click(R.id.AbstractViewSample2);

        $onClick(R.id.AbstractViewSample3, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tv.setVisibility(tv.getVisibility() == View.VISIBLE ? View.INVISIBLE : View.VISIBLE);
            }
        });

        //getData();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.AbstractViewSample1:
                $Title(R.id.AbstractViewSample, "AbstractViewSample1");
                break;
            case R.id.AbstractViewSample2:
                $Title(R.id.AbstractViewSample, "AbstractViewSample2");
                break;
            default:
                break;
        }
    }
}
